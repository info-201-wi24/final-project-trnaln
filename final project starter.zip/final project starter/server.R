
server <- function(input, output){
  
  # TODO Make outputs based on the UI inputs here
  
}